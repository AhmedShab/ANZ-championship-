﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ANZ_championship
{


    public class Team
    {

        private String name = "";
        private int allWin = 0;
        private int allLose = 0;
        
        
        //Home team feilds
        private int homeScore = 0;
        private int homeWin = 0;
        private int homelose = 0;

        //Away team feilds

        private int awayScore = 0;
        private int awayWin = 0;
        private int awaylose = 0;




        public Team(String name)
        {
            this.setName(name);
        }




        public String getName()
        {
            return name;
        }




        public void setName(String name)
        {
            this.name = name;
        }




        public int getHomeScore()
        {
            return homeScore;
        }




        public void setHomeScore(int homeScore)
        {
            this.homeScore = homeScore;
        }




        public int getAllWin()
        {
            return allWin;
        }




        public void setAllWin(int allWin)
        {
            this.allWin = allWin;
        }




        public int getHomeWin()
        {
            return homeWin;
        }




        public void setHomeWin(int homeWin)
        {
            this.homeWin += homeWin;
        }




        public int getHomelose()
        {
            return homelose;
        }




        public void setHomelose(int homelose)
        {
            this.homelose += homelose;
        }




        public int getAwayScore()
        {
            return awayScore;
        }




        public void setAwayScore(int awayScore)
        {
            this.awayScore += awayScore;
        }




        public int getAllLose()
        {
            return allLose;
        }




        public void setAllLose(int allLose)
        {
            this.allLose = allLose;
        }




        public int getAwayWin()
        {
            return awayWin;
        }




        public void setAwayWin(int awayWin)
        {
            this.awayWin += awayWin;
        }




        public int getAwaylose()
        {
            return awaylose;
        }




        public void setAwaylose(int awaylose)
        {
            this.awaylose += awaylose;
        }
    }
}